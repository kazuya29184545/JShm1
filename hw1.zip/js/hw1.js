let greeting = "Welcome to my calculator";

let numOne = 5;
let numTwo = 7;
let numTotal = numOne + numTwo;
let calculating = "The sum of " + numOne + " + " + numTwo + " is : " + numTotal;

let fisrtLine = document.getElementById('greet');
let secondLine = document.getElementById('calculate');

fisrtLine.textContent = greeting;
secondLine.textContent = calculating;
